package ex14.step1;

public class BoardController {

    public void insert() {
        System.out.println("insert 호출됨");
    }

    public void delete() {
        System.out.println("delete 호출됨");
    }

    public void update() {
        System.out.println("update 호출됨");
    }
}
